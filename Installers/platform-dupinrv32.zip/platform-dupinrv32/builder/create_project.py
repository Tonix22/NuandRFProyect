#!/usr/bin/env python
#  Dupin SoC - FPGAParadox
#
#  Copyright (C) 2021  Diego H <dhdezr@fpgaparadox.com>
#
#  Permission to use, copy, modify, and/or distribute this software for any
#  purpose with or without fee is hereby granted, provided that the above
#  copyright notice and this permission notice appear in all copies.
#
#  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
#  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
#  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
#  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
#  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
#  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
#  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
import os
import argparse
from distutils.dir_util import copy_tree
import getpass

# Warning: Unused function for this script
def check_path (dir):
    if os.path.isdir(dir):
        return dir
    else:
        raise argparse.ArgumentTypeError(f"readable_dir:{dir} is not a valid path.")

def create_path (dir):
    if not os.path.exists(dir):
        os.makedirs(dir)
    return dir

def get_pio_dir():
    pio_install_user = getpass.getuser()
    return os.path.join("/home/", pio_install_user, ".platformio/platforms/platform-dupinrv32/examples/empty_template")

parser = argparse.ArgumentParser(description='Create a project ready for Dupin IDE.')
parser.add_argument('onchip_memory', type=str, help='the memory size of the Dupin SoC version (in kb).')
parser.add_argument('project_dir', type=create_path , help='the directory where the project should be stored.')
parser.add_argument('editor', type=str, help='preferred editor to open the new project. Supported editors are eclipse | vscode.')
args = parser.parse_args()

# copy pio empty template project
pio_dir = get_pio_dir()
copy_tree(pio_dir, args.project_dir)

# open the platformio.ini and set the openocd path
openocd_paths = {'LENGTH = 256':'LENGTH = '+args.onchip_memory}
with open(args.project_dir+'/default_or.ld', 'r') as inf, open(args.project_dir+'/default.ld', 'w') as outf:
    for line in inf:
        for src, target in openocd_paths.items():
            line = line.replace(src, target)
        outf.write(line)

os.remove(args.project_dir+'/default_or.ld')

# update if eclipse env
if (args.editor == "eclipse"):
    print ("Setting up a project using eclipse platform with the following arguments:")
    os.system("pio project init --ide eclipse -e dupin_baremetal -d " + args.project_dir)

# Finalising
if (args.editor == "eclipse"):
    os.system(args.editor + "&")
else:
    open_proj = args.editor + ' ' + args.project_dir
    os.system(open_proj)

# Create a project manually
# pio project init --ide eclipse --board dupin_baremetal --project-option="upload_protocol=custom" --project-option="upload_command=share/bin/upload_fpga" --project-option="debug_tool=custom" --project-option="debug_server=openocd -f share/config/olimex-arm-usb-tiny-h.cfg -c \"set DUPIN_S_CFG share/config/cpu0.yaml\" -f share/config/dupin_s.cfg"
# update environment
# pio project init --ide eclipse -e dupin_baremetal
