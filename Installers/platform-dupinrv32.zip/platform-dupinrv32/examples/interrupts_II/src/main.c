#include <stdint.h>
#include "dupin.h"
#include "plic_metal.h"
#include "config.h"

void trap()
{
	int32_t mcause = csr_read(mcause);
	int32_t interrupt = mcause < 0;
	int32_t cause     = mcause & 0xF;
	if(interrupt){
		switch(cause){
		case CAUSE_MACHINE_TIMER: timerInterrupt(); break;
		case CAUSE_MACHINE_EXTERNAL: externalInterrupt(); break;
		default: crash(); break;
		}
	} else {
		crash();
	}
}

void timerInterrupt() {
    static uint32_t counter = 0;
	scheduleTimer();
	bsp_uart_write_string(UART_CONSOLE, "TIMER SECONDS = ");
	bsp_uart_write(UART_CONSOLE, '0' + counter);
	bsp_uart_write(UART_CONSOLE, '\n');
	if(++counter == 10) counter = 0;
}

void externalInterrupt ()
{
	uint32_t claim;
	while((claim = plic_claim(PLIC, PLIC_CPU_0))) {
        bsp_uart_write (UART_CONSOLE, '0' + claim + ' ');
		switch(claim){
			case PLIC_INT_0: bsp_uart_write_string(UART_CONSOLE, "PLIC_INT_0\n"); break;
			case PLIC_INT_1: bsp_uart_write_string(UART_CONSOLE, "PLIC_INT_1\n"); break;
			case PLIC_INT_2: bsp_uart_write_string(UART_CONSOLE, "PLIC_INT_2\n"); break;
			case PLIC_INT_3: bsp_uart_write_string(UART_CONSOLE, "PLIC_INT_3\n"); break;
			default: crash(); break;
		}
		plic_release(PLIC, PLIC_CPU_0, claim);
	}
}


int main ()
{
	configure_interrupts();
	bsp_uart_write_string(UART_CONSOLE, "*** Interrupts demo ***\n");
	bsp_uart_write_string(UART_CONSOLE, "Press a button\n");
	while(1);
}