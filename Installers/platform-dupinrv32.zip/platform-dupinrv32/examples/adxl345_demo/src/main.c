/*
 * 	I2C Demo: Dupin example
 *
 *  Copyright (C) 2021  Diego Hernandez <dhdezr@fpgaparadox.com>
 *
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */
#include <stdint.h>
#include "dupin.h"
#include "i2c_device.h"

#define ADXL345_RD_ADDRESS 0x3B
#define ADXL345_WR_ADDRESS 0x3A
#define ADXL345_DEVID_REG  0x00
#define ADXL345_DEVID_ANS  0xe5
#define ADXL345_POWER_CTL  0x2D

int main()
{
	// This literal will store the value returned by the adxl345
	u8 who_am_i;

	// Literal to store the adxl345 measurement
	u8 lecture_test;

	// enable the gpio
	PORTA->OUTPUT_ENABLE=0xff;
	PORTA->OUTPUT=0x00;

	// Configure the I2C0 device in fast mode (400KHz).
	bsp_i2c_fast_init(I2C0);

	// Request a read to the adxl435, in the devid register
	bsp_transmit_byte_i2c(I2C0, ADXL345_WR_ADDRESS, ADXL345_DEVID_REG);

	// Read the result from the adxl345
	who_am_i = bsp_receive_byte_i2c(I2C0, ADXL345_RD_ADDRESS);

	// Check that the devid value is returned as expected
	if (who_am_i != ADXL345_DEVID_ANS) {
		bsp_uart_write_string(UART_CONSOLE, "ERROR: No ADXL345 found.\n");
		return 1;
	}

	bsp_uart_write_string(UART_CONSOLE, "Device found, configuring for a simple measure.\n");

	// Configure POWER_CTL register and set MEASURE register
	bsp_transmit_twobytes(I2C0, ADXL345_WR_ADDRESS, ADXL345_POWER_CTL, 0x08);

	while (1) {
		// Get the X-AXIS register value (DATAX0)
		bsp_transmit_byte_i2c(I2C0, ADXL345_WR_ADDRESS, 0x32);
		// Receive the read from the adxl345
		lecture_test = bsp_receive_byte_i2c (I2C0, ADXL345_RD_ADDRESS);
		PORTA->OUTPUT=lecture_test;
	}

}