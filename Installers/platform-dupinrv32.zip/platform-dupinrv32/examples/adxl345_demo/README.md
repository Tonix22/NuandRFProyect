# ADXL345 Demo

## Application Note 001
It is recommended to check [appnote001.pdf](https://github.com/dh73/dupin_ide_package/blob/main/examples/adxl345_demo/doc/appnote001.pdf) for a better understanding of this demo.
