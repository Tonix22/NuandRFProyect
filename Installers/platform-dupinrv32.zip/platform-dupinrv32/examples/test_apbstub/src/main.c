/*
 * 	Empty template: Dupin example
 *
 *  Copyright (C) 2021  Diego Hernandez <dhdezr@fpgaparadox.com>
 *
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */

#include "dupin.h"
#include <stdint.h>

int main (void)
{
	// Variable to store the result of the Apb3Stub Operation
	static uint32_t result = 0;

	// Write some values
	APB3_STUB->write_port0=0x0005;
	APB3_STUB->write_port1=0x0004;

	// Read the result
	result = APB3_STUB->read_result;
	
	// Compare
	if (result == 20) // 0x0005 * 0x0004 = 0x0014
		bsp_uart_write_string (UART_CONSOLE, "--->>> Result match\n");
	else
		bsp_uart_write_string (UART_CONSOLE, "--->>> Result does not match\n");
	
	return 0;
}

