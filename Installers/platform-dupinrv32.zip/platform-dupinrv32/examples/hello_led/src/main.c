/*
 * 	LEDs: Dupin example
 *
 *  Copyright (C) 2021  Diego Hernandez <dhdezr@fpgaparadox.com>
 *
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */

#include <stdint.h>
#include "dupin.h"

/* @start Emulate a HAL for GPIOs */
void GpioSetupOutput(gpio_dev_reg* dev)
{
	dev->OUTPUT_ENABLE = 0xF;
	asm volatile("");
	dev->OUTPUT = 0x0;
}

void DigitalWrite(gpio_dev_reg* dev, uint32_t value)
{
	dev->OUTPUT = value;
}

static void delay(int cycles)
{
	for (uint32_t idx = 0; idx < cycles; idx++) asm volatile("");
}
/* @end */

// Emulate monitor HAL
void print (char* str)
{
	bsp_uart_write_string(UART_CONSOLE, str);
}

int main (void)
{
	GpioSetupOutput(GPIO0);
	GpioSetupOutput(GPIO1);
	print("Configured both GPIO0 and GPIO1 as output.\n");
	print("Will continue to show some LED subroutines, please watch the GPIOA and GPIOB ports.\n.");

	while (1) {
		for (uint32_t i = 0x1; i < 0x8; i=i*0x2) {
			DigitalWrite(GPIO0, i);
			delay(200000);
		}

		for (uint32_t j = 0x1; j < 0x8; j=j*0x2) {
			DigitalWrite(GPIO1, j);
			delay(200000);
		}
	}
}