#include <stdint.h>
#include "dupin.h"
#include "machineTimer.h"
#include "plic.h"
#include "config.h"

#define TIMER_TICK_DELAY (MACHINE_TIMER_HZ)

// Configure PLIC
void configure_interrupts();

int main ();

// This function is called when interupt is activated
void trap();

// Callback function to catch any config problem
void crash();

// Interrupt config. DO NOT MODIFY
void trap_entry();

// Timer example
void timerInterrupt();

// External interrupt example
void externalInterrupt();

// Timer helpers
void initTimer();
void scheduleTimer();

int main ()
{
	configure_interrupts();
	bsp_uart_write_string(UART_CONSOLE, "*** Interrupts demo ***\n");
	bsp_uart_write_string(UART_CONSOLE, "Press a button\n");
	while(1);
}

void configure_interrupts()
{
	// See the documentation provided in this release
	plic_set_threshold(PLIC, PLIC_CPU_0, 0);

	plic_set_enable(PLIC, PLIC_CPU_0, PLIC_GPIO_A_0, 1);
	plic_set_priority(PLIC, PLIC_GPIO_A_0, 1);

	plic_set_enable(PLIC, PLIC_CPU_0, PLIC_GPIO_A_1, 1);
	plic_set_priority(PLIC, PLIC_GPIO_A_1, 1);

	plic_set_enable(PLIC, PLIC_CPU_0, PLIC_GPIO_A_2, 1);
	plic_set_priority(PLIC, PLIC_GPIO_A_2, 1);

	plic_set_enable(PLIC, PLIC_CPU_0, PLIC_GPIO_A_3, 1);
	plic_set_priority(PLIC, PLIC_GPIO_A_3, 1);

	PORTA->INTERRUPT_RISE_ENABLE = 0xf;

	initTimer();

	//enable interrupts
	csr_write(mtvec, trap_entry);
	csr_set(mie, MIE_MTIE | MIE_MEIE);
	csr_write(mstatus, MSTATUS_MPP | MSTATUS_MIE);
}

uint64_t timerCmp;

void initTimer()
{
    timerCmp = timer_get_time(MACHINE_TIMER);
    scheduleTimer();
}

void scheduleTimer()
{
    timerCmp += TIMER_TICK_DELAY;
    timer_set_comparator(MACHINE_TIMER, timerCmp);
}

void trap()
{
	int32_t mcause = csr_read(mcause);
	int32_t interrupt = mcause < 0;
	int32_t cause     = mcause & 0xF;
	if(interrupt){
		switch(cause){
		case CAUSE_MACHINE_TIMER: timerInterrupt(); break;
		case CAUSE_MACHINE_EXTERNAL: externalInterrupt(); break;
		default: crash(); break;
		}
	} else {
		crash();
	}
}

void timerInterrupt() {
    static uint32_t counter = 0;
	scheduleTimer();
	bsp_uart_write_string(UART_CONSOLE, "TIMER SECONDS = ");
	bsp_uart_write(UART_CONSOLE, '0' + counter);
	bsp_uart_write(UART_CONSOLE, '\n');
	if(++counter == 10) counter = 0;
}

void externalInterrupt ()
{
	uint32_t claim;
	while((claim = plic_claim(PLIC, PLIC_CPU_0))) {
        bsp_uart_write (UART_CONSOLE, '0' + claim + ' ');
		switch(claim){
			case PLIC_GPIO_A_0: bsp_uart_write_string(UART_CONSOLE, "PLIC_GPIO_A_0\n"); break;
			case PLIC_GPIO_A_1: bsp_uart_write_string(UART_CONSOLE, "PLIC_GPIO_A_1\n"); break;
			case PLIC_GPIO_A_2: bsp_uart_write_string(UART_CONSOLE, "PLIC_GPIO_A_2\n"); break;
			case PLIC_GPIO_A_3: bsp_uart_write_string(UART_CONSOLE, "PLIC_GPIO_A_3\n"); break;
			default: crash(); break;
		}
		plic_release(PLIC, PLIC_CPU_0, claim);
	}
}

//Used on unexpected trap/interrupt codes
void crash()
{
	bsp_uart_write_string(UART_CONSOLE, "\n*** YIKESS!!. System Crashed. ***\n");
	while(1);
}

