#include <stdint.h>
#include "dupin.h"

int main (void)
{
	int i = 0;
	do {
		bsp_uart_write_string(UART_CONSOLE, "Hello World!\n");
		i++;
	} while (i < 10);
}


