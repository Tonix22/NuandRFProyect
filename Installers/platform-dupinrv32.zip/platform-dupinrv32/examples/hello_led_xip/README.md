# Dupin Xip Example

## Instructions
Follow the normal flow, select `dupin_baremetal_xip` as target, and upload the firmware image. After that, configure the FPGA with the correct `bitstream`.

## Notes
**Debug** is not supported for this platform yet, no matter if OpenOCD targets the on-chip ram, the debugger will not answer as all the information is stored in the flash.
Drivers for OpenOCD are needed for debug purposes, and they are not actually developed.
