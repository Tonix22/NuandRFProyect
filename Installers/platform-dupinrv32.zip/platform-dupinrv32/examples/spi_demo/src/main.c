/*
 * 	Empty template: Dupin example
 *
 *  Copyright (C) 2021  Diego Hernandez <dhdezr@fpgaparadox.com>
 *
 *  Permission to use, copy, modify, and/or distribute this software for any
 *  purpose with or without fee is hereby granted, provided that the above
 *  copyright notice and this permission notice appear in all copies.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *  WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *  ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *  WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *  ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *  OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */
#include <stdint.h>
#include "dupin.h"

// Spi Configuration for the LIS3DH
#define SPI_CPOL 1
#define SPI_CPHA 1
#define SPI_MODE 0
#define SPI_DIV  4
#define SPI_TCS  10
#define SPI_TCH  40
#define SPI_TDIS 50
#define SPI0 SPI0_BASE
#define WHOAMI_REG 0x33

void SpiDevice (uint32_t cpol, uint32_t cpha, uint32_t mode,
				uint32_t div, uint32_t csSetup, uint32_t csHold,
				uint32_t csDis)
{
	// Creating the SPI structure to confgure the registers
	spi_config_reg s;

	// Register configuration
	s.cpol = cpol;
	s.cpha = cpha;
	s.mode = mode;
	s.clkDivider = div;
	s.ssSetup = csSetup;
	s.ssHold = csHold;
	s.ssDisable = csDis;

	// Apply configuration
	spi_configure (SPI0, &s);

}

int LIS3DH_scan (void)
{
	uint8_t whoami = 0;
	spi_select_device (SPI0, 0);
	spi_txbyte (SPI0, 0x8F);
	whoami = spi_rxdat (SPI0);
	spi_deselect_device (SPI0, 0);
	if (whoami == WHOAMI_REG)
		return 1;
	return 0;
}

int main (void)
{

	int found = 0;
	found = LIS3DH_scan ();
	if (found)
		bsp_uart_write_string (UART_CONSOLE, "LIS3DH Device found :).\n");
	else
		bsp_uart_write_string (UART_CONSOLE, "LIS3DH Device not found :(.\n");

	return 0;
}
